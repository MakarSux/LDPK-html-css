﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class ClsSquare :ClsRectangle
    {
        private double sideA;
        public void SidesCalculation()
        {
            sideA = Math.Sqrt((X1 - X2) * (X1 - X2) + (Y1 - Y2) * (Y1 - Y2));
        }
        public double Perimetr()
        {
            return sideA*4;
        }
        public double Ploshad()
        {
            double s = 0;
            s = sideA * sideA;
            return s;
        }
    }
}
